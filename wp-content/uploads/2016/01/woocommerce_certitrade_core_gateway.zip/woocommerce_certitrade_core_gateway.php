<?php
/*
 * Plugin Name: WooCommerce Certitrade Core Gateway
 * Plugin URI: https://www.certitrade.se
 * Description: Extends WooCommerce with Certitrades payment service. Provides a <a href="https://www.certitrade.se/" target="_blank">Certitrade</a> gateway for WooCommerce.
 * Version: 1.1.0
 * Author: Certitrade AB
 * Author URI: https://www.certitrade.se
 */

// Init Certitrade Core Gateway after WooCommerce has loaded
add_action('plugins_loaded', 'init_certitrade_core_gateway', 0);

function init_certitrade_core_gateway()
{
    
    // If the WooCommerce payment gateway class is not available, do nothing
    if (! class_exists('WC_Payment_Gateway'))
        return;
    /**
     * Localisation
     */
    load_plugin_textdomain('certitrade', false, dirname( plugin_basename( __FILE__ ) ) . '/languages');
    
    class WC_Gateway_Certitrade_Core extends WC_Payment_Gateway
    {

        protected $debug="no";
        protected $merchantId = 0;
        protected $api_key = "";
        protected $api_key_test = "";
        protected $url_test = "";
        protected $paymentMethod;
        
        protected $usedApiKey = "";
        protected $usedUrl = "";
        
        
        public function __construct()
        {
            global $woocommerce;
            
            $this->certitrade_currency = array(
                'DKK' => '208', // Danish Kroner
                'EUR' => '978', // Euro
                'USD' => '840', // US Dollar $
                'GBP' => '826', // English Pound £
                'SEK' => '752', // Swedish Kroner
                'AUD' => '036', // Australian Dollar
                'CAD' => '124', // Canadian Dollar
                'ISK' => '352', // Icelandic Kroner
                'JPY' => '392', // Japanese Yen
                'NZD' => '554', // New Zealand Dollar
                'NOK' => '578', // Norwegian Kroner
                'CHF' => '756', // Swiss Franc
                'TRY' => '949' // Turkish Lire                
            );
        }
        public function logDebug($message)
        {
            if ($this->debug == 'yes') {
                 $handle = fopen(ABSPATH."log/wc_certitrade.log", "a+");
                fwrite($handle, date("Y-m-d H:i:s") . " " . $message . "\n");
                fclose($handle);
            }
        }
    
    }
    
    // Include our Credit Card purchase class
    require_once 'class-certitrade-common.php';
    require_once 'class-certitrade-card.php';
    require_once 'class-certitrade-swish.php';
    require_once 'lib/certitrade-api.php';
    require_once 'lib/class-certitrade-payment.php';





} // Close init_certitrade_gateway




/**
 * Add the gateways to WooCommerce
 */
function add_certitrade_core_gateway($methods)
{
    $methods[] = 'WC_Gateway_Certitrade_Card';
    $methods[] = 'WC_Gateway_Certitrade_Swish';
    
    return $methods;
}

add_filter('woocommerce_payment_gateways', 'add_certitrade_core_gateway');

