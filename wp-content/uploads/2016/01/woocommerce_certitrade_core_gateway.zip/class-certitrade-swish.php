<?php

class WC_Gateway_Certitrade_Swish extends WC_Gateway_Certitrade_Common
{

    public function __construct()
    {
        parent::__construct();
        
        $this->id = 'certitrade_swish';
        $this->method_title = __('Certitrade Swish', 'certitrade');
        $this->paymentMethod = "SWISH_E";
        
        // Load the form fields.
        $this->init_form_fields();
        
        // Load the settings.
        $this->init_settings();
        
        $this->title = (isset($this->settings['title'])) ? $this->settings['title'] : '';
        $this->enabled = (isset($this->settings['enabled'])) ? $this->settings['enabled'] : '';
        $this->description = (isset($this->settings['description'])) ? $this->settings['description'] : '';
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(
            $this,
            'process_admin_options'
        ));
    }

    protected function setDataArray($customer_order)
    {
        return (array(
            'SWISH_E' => array(
                'payer_phone_number' => $customer_order->get_billing_phone()
            )
        ));
    }

    protected function getPaymentInfo($function, $paymentAttempt)
    {
        $info = "";
        switch ($function) {
            case "APPROVE":
                $info = "<br>Swish payment reference: " . $paymentAttempt->SWISH_E->swish_payment_reference;
                
                break;
            case "ERROR":
                $info = "<br>Swish error code: " . $paymentAttempt->SWISH_E->swish_error_code;
                $info .= "<br>Swish error message: " . $paymentAttempt->SWISH_E->swish_error_message;
                $info .= '<br><a href="https://www.certitrade.se/merchantinfo/swishinformation">More information</a>';
                
                break;
            
            case "CANCEL":
                
                break;
            
            default:
                ;
                break;
        }
        
        return "$info";
    }

    function init_form_fields()
    {
        $this->form_fields = array(
            'enabled' => array(
                'title' => __('Enable/Disable', 'certitrade'),
                'type' => 'checkbox',
                'label' => __('Enable Certitrade Swish', 'certitrade'),
                'default' => 'yes'
            ),
            'title' => array(
                'title' => __('Title', 'certitrade'),
                'type' => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'certitrade'),
                'default' => __('Certitrade Swish', 'certitrade')
            ),
            'description' => array(
                'title' => __('Description', 'certitrade'),
                'type' => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'certitrade'),
                'default' => __("Pay via Certitrade using Swish.", 'certitrade')
            )
        );
    } // End init_form_fields()
}
