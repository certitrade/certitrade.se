<?php

class CertitradePayment{
    
    private $paymentData=NULL;
    
    public function __construct($paymentData){
        
        $this->paymentData = $paymentData;
    }

    public function getPaymentID(){
        return $this->paymentData->id;
    }
    
    public function getReference(){
        return $this->paymentData->reference;
    }
    
    public function getMethod(){
        return $this->paymentData->method;
    }
    
    public function getResponce(){
        $attempts = $this->paymentData->payment_attempts;
        if (is_array($attempts)){
            foreach ($attempts as $attempt) {
                ;
            }           
            return $attempt->data;
        } else {
            return null;
        }
    }

}