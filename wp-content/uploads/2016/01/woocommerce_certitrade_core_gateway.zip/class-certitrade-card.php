<?php

class WC_Gateway_Certitrade_Card extends WC_Gateway_Certitrade_Common
{

    public function __construct()
    {
        parent::__construct();
        
        $this->id = 'certitrade_common';
        $this->method_title = __('Certitrade Card', 'certitrade');
        $this->paymentMethod = "CARD";
        
        // Load the form fields.
        $this->init_form_fields();
        
        // Load the settings.
        
        $this->title = (isset($this->settings['title'])) ? $this->settings['title'] : __('Certitrade Card', 'certitrade');
        $this->enabled = (isset($this->settings['enabled'])) ? $this->settings['enabled'] : '';
        $this->description = (isset($this->settings['description'])) ? $this->settings['description'] : '';
        $this->merchant_id = (isset($this->settings['merchant_id'])) ? $this->settings['merchant_id'] : '';
        $this->api_key = (isset($this->settings['api_key'])) ? $this->settings['api_key'] : '';
        $this->language = (isset($this->settings['language'])) ? $this->settings['language'] : '';
        $this->testmode = (isset($this->settings['testmode'])) ? $this->settings['testmode'] : '';
         
        
        $this->debug = (isset($this->settings['debug'])) ? $this->settings['debug'] : '';
        
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(
        $this,
        'process_admin_options'
            ));
        
        
    }

    protected function setDataArray($customer_order)
    {
        return (array());
    }

    protected function getPaymentInfo($function, $paymentAttempt)
    {
        $info = "";
        switch ($function) {
            case "APPROVE":
                
                $info = "<br>Bank reference: " . $paymentAttempt->CARD->authcode;
                $info .= "<br>Masked cardno: " . $paymentAttempt->CARD->bin . $paymentAttempt->CARD->masked_cardno;
                
                break;
            case "DECLINE":
                $info = "<br>Bank response code: " . $paymentAttempt->CARD->respcode . ' <br><a href="https://www.certitrade.se/merchantinfo/responsecodes">Read about responsecode</a>';
                $info .= "<br>Masked cardno: " . $paymentAttempt->CARD->bin . $paymentAttempt->CARD->masked_cardno;
                break;
            
            case "CANCEL":
                
                break;
            
            default:
                ;
                break;
        }
        
        return "$info";
    }

    function init_form_fields()
    {
        
        $this->form_fields = array(
            'enabled' => array(
                'title' => __('Enable/Disable', 'certitrade'),
                'type' => 'checkbox',
                'label' => __('Enable Certitrade Credit Card', 'certitrade'),
                'default' => 'yes'
            ),
            'title' => array(
                'title' => __('Title', 'certitrade'),
                'type' => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'certitrade'),
                'default' => __('Certitrade Credit Card', 'certitrade')
            ),
            'description' => array(
                'title' => __('Description', 'certitrade'),
                'type' => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'certitrade'),
                'default' => __("Pay via Certitrade using credit card.", 'certitrade')
            ),
            'merchant_id' => array(
                'title' => __('Certitrade Merchant ID', 'certitrade'),
                'type' => 'text',
                'description' => __('Please enter your Certitrade Credit Card Merchant ID; this is needed in order to take payment.', 'certitrade'),
                'default' => ''
            ),
            'api_key' => array(
                'title' => __('API key', 'certitrade'),
                'type' => 'text',
                'description' => __('Please enter your Certitrade api key; this is needed in order to take payment.', 'certitrade'),
                'default' => ''
            ),
 /*            
            'language' => array(
                'title' => __('Language', 'certitrade'),
                'type' => 'select',
                'options' => array(
                    'en' => 'English',
                    'da' => 'Danish',
                    'no' => 'Norwegian',
                    'sv' => 'Swedish'
                ),
                'description' => __('Set the language in which the page will be opened when the customer is redirected to Certitrade.', 'certitrade'),
                'default' => 'sv'
            ),
            
 */            
            'testmode' => array(
                'title' => __('Test Mode', 'certitrade'),
                'type' => 'checkbox',
                'label' => __('Enable Certitrade Test Mode.', 'certitrade'),
                'default' => 'yes'
            ),
            'api_key_test' => array(
                'title' => __('API key test', 'certitrade'),
                'type' => 'text',
                'description' => __('Please enter your Certitrade api key for the test site; this is needed in order to test payments.', 'certitrade'),
                'default' => ''
            ),
            'url_test' => array(
                'title' => __('Test site URL ', 'certitrade'),
                'type' => 'text',
                'description' => __('Please enter the URL to the testsite. (Standard: https://apitest.certitrade.net)', 'certitrade'),
                'default' => 'https://apitest.certitrade.net'
            
            ),
            'debug' => array(
                'title' => __('Debug', 'certitrade'),
                'type' => 'checkbox',
                'label' => __('Enable logging', 'certitrade').' ('.ABSPATH.'log/wc_certitrade.log)',
                'default' => 'no'
            )
        );
    } // End init_form_fields()
}