<?php

class WC_Gateway_Certitrade_Common extends WC_Gateway_Certitrade_Core
{


    public function __construct()
    {
        parent::__construct();
        
        $this->id = 'certitrade_common';
        $this->method_title = __('Certitrade Card', 'certitrade');
        $this->paymenMethod = "";
        
        $this->icon = plugins_url(basename(dirname(__FILE__)) . "/images/certitrade_card.png");
        $this->has_fields = false;
        // $this->log = new CT_Logger();
        
        // Load the settings.
        $this->init_settings();
        
        $this->merchantId = (isset($this->settings['merchant_id'])) ? $this->settings['merchant_id'] : '';
        $this->api_key = (isset($this->settings['api_key'])) ? $this->settings['api_key'] : '';
        $this->testmode = (isset($this->settings['testmode'])) ? $this->settings['testmode'] : '';
        $this->api_key_test = (isset($this->settings['api_key_test'])) ? $this->settings['api_key_test'] : '';
        $this->url_test = (isset($this->settings['url_test'])) ? $this->settings['url_test'] : 'https://apitest.certitrade.net';
        
        
        $this->debug = (isset($this->settings['debug'])) ? $this->settings['debug'] : '';
        
        if ($this->testmode =='yes'){
            $this->usedUrl = $this->url_test;
            $this->usedApiKey = $this->api_key_test;
        } else{
            $this->usedUrl = "https://api.certitrade.net";
            $this->usedApiKey = $this->api_key;
            
        }
        
        /* 
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(
            $this,
            'process_admin_options'
        ));
         */
        
        add_action('woocommerce_receipt_certitrade_common', array(
            &$this,
            'receipt_page'
        ));
        
        /*
         * Register the function to handel all callbacks from the Certitrade API
         */
        add_action('woocommerce_api_wc_gateway_certitrade_common_callback', array(
            &$this,
            'callbackHandler'
        ));
    }

    /**
     * receipt_page
     */
    protected function setDataArray($customer_order)
    {
        return (array());
    }

    protected function getPaymentInfo($function, $paymentAttempt)
    {
        return "";
    }
    
    protected function getResponseInfo($info){
        return false;
    }

    function receipt_page($order)
    {
        echo '<p>' . __('Thank you for your order, please click the button below to pay with Certitrade.', 'certitrade') . '</p>';
    }
    /*
     * Callback handler
     */
    public function callbackHandler()
    {
        $key = $_GET['key'];
        $order_id = $_GET['orderId'];
        
        $resp = $_POST;
        
        $paymentId = (int) $resp['paymentid'];
        $function = $resp['function'];
        
        $apiClient = new CertitradeApiClient($this->merchantId, $this->usedApiKey, $this->usedUrl);
        $paymentData = $apiClient->get_payment($paymentId);
        
        $payment = new CertitradePayment($paymentData);
        
        if ($payment->getMethod() != $this->paymentMethod) {
            return;
        }
        
        $tmp = print_r($resp, true);
        $this->logDebug("Callback POST data: " . $tmp);
        
        $tmp = print_r($paymentData, true);
        $this->logDebug("Payment data: " . $tmp);
        
        $order_id = (int) $payment->getReference();
        
        $customer_order = new WC_Order($order_id);
        
        $orderStatus = $customer_order->get_status();
        
        $paymentAttempt = $payment->getResponce();
        
        $info = $this->getPaymentInfo($function, $paymentAttempt);       
        
        
        switch ($function) {
            case "APPROVE":
                
                $customer_order->add_order_note('Certitrade payment completed. Certitrade Payment ID: ' . $paymentId . " " . $info);
                $customer_order->payment_complete();
                
                break;
            case "DECLINE":
                $customer_order->add_order_note('Certitrade payment declined. Certitrade Payment ID: ' . $paymentId . " " . $info);
                $customer_order->update_status('failed', 'Certitrade payment declined. Certitrade Payment ID: ' . $paymentId);
                
                break;
            
            case "ERROR":
                $customer_order->add_order_note('Certitrade payment error. Certitrade Payment ID: ' . $paymentId . " " . $info);
                $customer_order->update_status('failed', 'Certitrade payment error. Certitrade Payment ID: ' . $paymentId);
                
                break;
            
            case "CANCEL":
                $customer_order->update_status('failed', 'Certitrade payment customer cancel. Certitrade Payment ID: ' . $paymentId);
                exit();
                
                break;
            default:
                ;
                break;
        }
    }

    function process_payment($order_id)
    {
        global $woocommerce;
        
        $this->logDebug('process_payment: ' . $order_id . "  " . $this->merchantId . " " . $this->usedApiKey);
        
        // Get this Order's information so that we know
        // who to charge and how much
        $customer_order = new WC_Order($order_id);
        
        $apiClient = new CertitradeApiClient($this->merchantId, $this->usedApiKey, $this->usedUrl);
        
        $callbackUrl = trailingslashit(home_url()) . '?wc-api=WC_Gateway_Certitrade_Common_Callback&key=' . $customer_order->get_order_key() . '&orderId=' . $order_id;
        $returnUrl = $this->get_return_url($customer_order);
        
        $amount = ($customer_order->order_total * 100);
        $currency = get_woocommerce_currency();
        $reference = trim($this->settings['gwdescription']);
        $description = trim($this->settings['gwdescription']);
        $language = 'sv';
        
        $this->logDebug('order: ' . "$amount- $currency - $reference - $description - $language - $this->paymentMethod");
        
        $dataload = array(
            'amount' => $amount,
            'currency' => $currency,
            'return_url' => $returnUrl,
            'callback_url' => $callbackUrl,
            'reference' => $order_id,
            'description' => $description,
//            'description' => "RP06", // Swish error test
            'language' => $language,
            'customer' => array(
                'phone' => $customer_order->get_billing_phone(),
                'name' => $customer_order->get_billing_first_name() . " " . $customer_order->get_billing_last_name(),
                'address1' => $customer_order->get_billing_address_1(),
                'address2' => $customer_order->get_billing_address_2(),
                'zip_code' => $customer_order->get_billing_postcode(),
                'city' => $customer_order->get_billing_city(),
                'region' => $customer_order->get_billing_state(),
                'country' => $customer_order->get_billing_country(),
                'email' => $customer_order->get_billing_email()
            ),
            
            'data' => $this->setDataArray($customer_order)
        );
        
        $response = $apiClient->create_payment($dataload, $this->paymentMethod);
        
        $this->logDebug('Create payment response: ' . $response);
        
        if ($response->httpStatus != NULL) {
            $this->logDebug("Can't create payment");
            $info = "Can't create payment: " . $response->title . " HTTP response code: " . $response->httpStatus;
            $customer_order->add_order_note($info);
        }
        
        $crtarray = array();
        
        // A single resource, like a Payment
        if ($response instanceof Resource) {
            
            $crtarray['rid'] = $response->id;
            $crtarray['rstate'] = $response->state;
            $crtarray['ramount'] = $response->amount;
            $crtarray['rpaywin'] = $response->getLink('paywin');
            add_post_meta($customer_order->id, '_transaction_id', $response->id, true);
        }
        
        return array(
            'result' => 'success',
            'redirect' => $crtarray['rpaywin']
        );
    }
}